package com.skillsnippets.skillsnips;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillSnipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillSnipsApplication.class, args);
	}

}
